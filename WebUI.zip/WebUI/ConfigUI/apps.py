from django.apps import AppConfig


class ConfiguiConfig(AppConfig):
    name = 'ConfigUI'
