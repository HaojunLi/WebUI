from django.shortcuts import render
import psycopg2
# Create your views here.
def Config(request):
    StudyID = request.path.replace('/Config/WhereStudyID=','')
    con = psycopg2.connect(
        host="masimdb.vmhost.psu.edu",
        database="masim",
        user="sim",
        password="sim")
    # cursor
    cur = con.cursor()
    cur.execute("select configuration.id, configuration.name, configuration.notes, configuration.filename," +
                " concat('(', ncols, ', ', nrows, ', ', xllcorner, ', ', yllcorner, ', ', cellsize, ')') as spatial, count(replicate.id) " +
                "from configuration left join replicate on replicate.configurationid = configuration.id where studyid = " + StudyID + 'group by configuration.id order by configuration.id')
    rows = cur.fetchall()
    cur.close()
    con.close()

    return render(request,"Config.html", {'rows': rows})