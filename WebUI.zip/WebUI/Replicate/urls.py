from django.urls import path
from . import views
import psycopg2
con = psycopg2.connect(
        host="masimdb.vmhost.psu.edu",
        database="masim",
        user="sim",
        password="sim")
# cursor
cur = con.cursor()
cur.execute("select count(*) from study")
num = cur.fetchall()
# close the cursor
cur.close()
con.close()
i = 1
urlpatterns = []
while i <= num[0][0]:
    urlpatterns.append(path('WhereStudyID='+str(i), views.replicateStudy, name='replicateStudy'))
    i += 1
