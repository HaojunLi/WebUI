from django.shortcuts import render
from datetime import datetime
# Create your views here.
import psycopg2
# Create your views here.
def replicateStudy(request):
    studyID = request.path.replace('/Replicate/WhereStudyID=','')
    con = psycopg2.connect(
        host="masimdb.vmhost.psu.edu",
        database="masim",
        user="sim",
        password="sim")
    # cursor
    cur = con.cursor()
    # sql
    sql = "select v_replicates.id, v_replicates.filename, v_replicates.starttime, v_replicates.endtime, v_replicates.movement, v_replicates.runningtime from study left join configuration on configuration.studyID = "\
          + studyID + "inner join v_replicates on v_replicates.configurationid = configuration.id where study.id = " + studyID + "order by v_replicates.id"
    cur.execute(sql)
    rows = cur.fetchall()
    rowsList = []
    for i in range(0,len(rows)):
        rowsList.append(list(rows[i]))
    for i in range(0,len(rowsList)):
        rowsList[i][2] = rowsList[i][2].strftime("%m/%d/%Y, %H:%M:%S")
        rowsList[i][3] = rowsList[i][3].strftime("%m/%d/%Y, %H:%M:%S")
        rowsList[i][5] = int(rowsList[i][5].total_seconds()* 1000000)
    cur.close()
    con.close()
    return render(request,'Replicate.html',{"rows":rowsList})