from django.apps import AppConfig


class ReplicateConfig(AppConfig):
    name = 'Replicate'
