from django.shortcuts import render
import psycopg2
# Create your views here.
def Study(request):
    con = psycopg2.connect(
        host="masimdb.vmhost.psu.edu",
        database="masim",
        user="sim",
        password="sim")
    # cursor
    cur = con.cursor()
    # execute query
    sql = "select s.id, s.name, count(r.id) as replicateid from sim.study s " \
          "left join sim.configuration c on c.studyid = s.id " \
          "left join sim.replicate r on r.configurationid = c.id group by s.id, s.name order by s.id"
    cur.execute(sql)
    rows = cur.fetchall()
    cur.close()
    cur = con.cursor()
    cur.execute("select study.id, study.name, count(configuration.id) from study join configuration on configuration.studyid = study.id group by study.id, study.name order by study.id")
    configuration = cur.fetchall()
    cur.close()
    # close the connection
    con.close()
    return render(request,"index.html",{"rows": rows,"configuration": configuration})