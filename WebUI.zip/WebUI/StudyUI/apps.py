from django.apps import AppConfig


class StudyuiConfig(AppConfig):
    name = 'StudyUI'
